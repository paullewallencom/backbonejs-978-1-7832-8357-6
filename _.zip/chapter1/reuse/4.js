var BaseView = Backbone.View.extend({
	close: function () {
    // Extra stuff goes here

    // Remove the view
    this.remove();
}
});

